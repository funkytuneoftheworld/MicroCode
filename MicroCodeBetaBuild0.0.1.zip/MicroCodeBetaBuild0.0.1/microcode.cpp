#include <iostream>
#include <fstream>
#include <string>
#include <Windows.h>

void runScript(const std::string& scriptPath) {
    std::ifstream file(scriptPath);
    if (file.is_open()) {
        std::string code((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        std::cout << "Executing code:\n" << code << std::endl;
    } else {
        std::cerr << "Error: Could not open script file." << std::endl;
    }
}

void compileScript(const std::string& scriptPath, const std::string& outputPath) {
    std::ifstream file(scriptPath);
    if (file.is_open()) {
        std::string code((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        std::ofstream outputFile(outputPath);
        if (outputFile.is_open()) {
            outputFile << "Compiled intermediate code for:\n" << code << std::endl;
            outputFile.close();
        } else {
            std::cerr << "Error: Could not open output file." << std::endl;
        }
    } else {
        std::cerr << "Error: Could not open script file." << std::endl;
    }
}

void toSource(const std::string& code, const std::string& outputPath) {
    std::ofstream outputFile(outputPath);
    if (outputFile.is_open()) {
        outputFile << code << std::endl;
        outputFile.close();
    } else {
        std::cerr << "Error: Could not open output file." << std::endl;
    }
}

void toIntermediate(const std::string& code, const std::string& outputPath) {
    std::ofstream outputFile(outputPath);
    if (outputFile.is_open()) {
        outputFile << "Compiled intermediate code for:\n" << code << std::endl;
        outputFile.close();
    } else {
        std::cerr << "Error: Could not open output file." << std::endl;
    }
}

void displayHelp() {
    std::cout << "MicroCode BETA copyright 2024 by funkytuneoftheworld Learn More." << std::endl;
    std::cout << "Usage: microcode <command> [<args>]" << std::endl;
    std::cout << "Commands: run, compile, tosource, tointermediate, cardinal, admin" << std::endl;
}

void displayLearnMore() {
    std::cout << "MicroCode is a modern programming language designed for simplicity and efficiency." << std::endl;
}

void spamCardinal() {
    for (int i = 0; i < 100; ++i) {
        std::cout << "CARDINALS DA BEST BURD!" << std::endl;
    }
}

void adminCommands() {
    std::cout << "Admin Mode Activated!" << std::endl;
    std::cout << "Available Admin Commands: reboot, shutdown, clean" << std::endl;
}

void checkAdmin() {
    BOOL isAdmin = FALSE;
    HANDLE token = NULL;

    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) {
        TOKEN_ELEVATION elevation;
        DWORD size;
        if (GetTokenInformation(token, TokenElevation, &elevation, sizeof(elevation), &size)) {
            isAdmin = elevation.TokenIsElevated;
        }
        CloseHandle(token);
    }

    if (isAdmin) {
        std::cout << "WHOA! IF YOU WANT TO USE THIS YOU GOTTA MAKE SURE WHAT YOU'RE DOING! THE CARDINAL WILL GIVE YOU HOPE THO." << std::endl;
        adminCommands();
    } else {
        std::cout << "Admin privileges are not available. Run the program as an administrator to access admin commands." << std::endl;
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        displayHelp();
        return 1;
    }

    std::string command = argv[1];

    if (command == "run") {
        if (argc != 3) {
            std::cerr << "Usage: microcode run <script.mcs>" << std::endl;
            return 1;
        }
        runScript(argv[2]);
    } else if (command == "compile") {
        if (argc != 5 || std::string(argv[3]) != "-o") {
            std::cerr << "Usage: microcode compile <script.mcs> -o <output.mci>" << std::endl;
            return 1;
        }
        compileScript(argv[2], argv[4]);
    } else if (command == "tosource") {
        if (argc != 5 || std::string(argv[3]) != "-o") {
            std::cerr << "Usage: microcode tosource \"<code>\" -o <output.mcs>" << std::endl;
            return 1;
        }
        toSource(argv[2], argv[4]);
    } else if (command == "tointermediate") {
        if (argc != 5 || std::string(argv[3]) != "-o") {
            std::cerr << "Usage: microcode tointermediate \"<code>\" -o <output.mci>" << std::endl;
            return 1;
        }
        toIntermediate(argv[2], argv[4]);
    } else if (command == "Learn" && std::string(argv[2]) == "More.") {
        displayLearnMore();
    } else if (command == "cardinal") {
        spamCardinal();
    } else if (command == "admin") {
        checkAdmin();
    } else {
        std::cerr << "Unknown command: " << command << std::endl;
        displayHelp();
    }

    return 0;
}
